<?php
session_start();
session_destroy();
include 'include/config.php'; 

?>
<html>
  <head>
     <title><?php echo $sitename;?></title>
	 <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	 <meta name="description" content="<?php echo $sitemeta;?>">
     <link href="css/bootstrap.css" rel="stylesheet">
	 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
     <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
     <script src="//cdnjs.cloudflare.com/ajax/libs/jquery-form-validator/2.3.26/jquery.form-validator.min.js"></script>
	 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	 </head>
<style>
.count{
	font-size: 20px;
    line-height: 47px;
    font-weight: 600;
	color: #73879C;
}

</style>
<body>
<nav class="navbar navbar-expand-md navbar-dark bg-dark">
      <a class="navbar-brand" href="index.php">EasyUser</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample04" aria-controls="navbarsExample04" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarsExample04">
        <ul class="navbar-nav mr-auto">
          <li class="nav-item active">
            <a class="nav-link" href="index.php">Home <span class="sr-only">(current)</span></a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="contact.php">Contact</a>
          </li>
          
        </ul>
        <ul class="nav navbar-nav navbar-right">
      <li><a href="register.php"><span class="glyphicon glyphicon-user"></span> Sign Up</a></li>
      <li><a href="login.php"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>
    </ul>
      </div>
    </nav>
	</br>
<div class="container">
	<div class="row">
         <div class="col-8"><?php
	     $sql = "SELECT * FROM easynews WHERE location=0 ";
                                $result = $conn->query($sql);
                                  if ($result->num_rows > 0) {
                                  while($row = $result->fetch_assoc()) {
								  if($row['location']==0){
									  
									  echo'<div class="panel-group"><h2 class="form-signin-heading">News Content</h2>
		      <div class="panel panel-primary">
      <div class="panel-heading">'.$row['title'].' </div>
      <div class="panel-body">
	  '.$row['news'].'
	  <hr>
	  <div style="float:left"><p class="card-text"><small class="text-muted">Created by : '.$row['creatorname'].' </small></p></div><div style="float:right"><p class="card-text"><small class="text-muted">Created date : '.$row['created'].' </small></p></div>
	  </div>
    </div>
		 </div> ';
								  }else{
									  echo'<div class="panel-group"><h2 class="form-signin-heading">News Content</h2>
		      <div class="panel panel-primary">
      <div class="panel-heading">No news</div>
      <div class="panel-body">
	  Please add news content...
	  <hr>
	  <div style="float:left"><p class="card-text"><small class="text-muted">Created by : ..... </small></p></div><div style="float:right"><p class="card-text"><small class="text-muted">Created date : ..... </small></p></div>
	  </div>
    </div>
		 </div> ';
								  }
								  }
								  
	}
	  ?>
	  <div class="card-group">
		 <?php
	     $sql = "SELECT * FROM easyuser ORDER BY id DESC LIMIT 5";
                                $result = $conn->query($sql);
                                  if ($result->num_rows > 0) {
                                  while($row = $result->fetch_assoc()) {
									  
									  echo'
  <div class="card" style="height:380x">
    <img class="img-thumbnail " style="min-height:150px" src="'.$row['avatar'].'"  alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title count">'.$row['username'].'</h5>
      <p class="card-text">Gender: '.$row['gender'].'</p>
      <p class="card-text"><small class="text-muted">Registered '.$row['logedin'].'</small></p>
    </div>
  </div>';
								  }
								  }
	  ?>
	  </div>
		 </div>
         <div class="col-4">
		 
		 <?php
	     $sql = "SELECT * FROM easynews WHERE location=1";
                                $result = $conn->query($sql);
                                  if ($result->num_rows > 0) {
                                  while($row = $result->fetch_assoc()) {
									 if($row['location']==1){
									  
									  echo'<div class="panel-group"><h2 class="form-signin-heading">News sidebar</h2>
		      <div class="panel panel-primary">
      <div class="panel-heading">'.$row['title'].' </div>
      <div class="panel-body">
	  '.$row['news'].'
	  <hr>
	  <div style="float:left"><p class="card-text"><small class="text-muted">Created by : '.$row['creatorname'].' </small></p></div><div style="float:right"><p class="card-text"><small class="text-muted">Created date : '.$row['created'].' </small></p></div>
	  </div>
    </div>
		 </div> ';
								  }else{
									  echo'<div class="panel-group"><h2 class="form-signin-heading">News 1</h2>
		      <div class="panel panel-primary">
      <div class="panel-heading">No news</div>
      <div class="panel-body">
	  Please add news content...
	  <hr>
	  <div style="float:left"><p class="card-text"><small class="text-muted">Created by : ..... </small></p></div><div style="float:right"><p class="card-text"><small class="text-muted">Created date : ..... </small></p></div>
	  </div>
    </div>
		 </div> ';
								  }
								  }
								  
	}
	
	  ?>
		        
		 
		 
		 
		 
		 
		 
             
			 
			 
         </div>
     </div>
</div>
</body>
<?php
$os=user_os();
$browser=get_user_browser();
$date = date("Y-m-d h:i:s");
$ip=user_ip();
$sql = "INSERT INTO easylog (os, browser, date, ip)
     VALUES ('$os', '$browser', '$date', '$ip')";

     if ($conn->query($sql) === TRUE) {
         echo "";
         } else {
         echo "Error: " . $sql . "<br>" . $conn->error;
    }






?>
</html>
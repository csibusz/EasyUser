﻿<?php
include 'include/config.php'; 



	
	

if(isset($_POST['name'])) {

	
     $name = inputfilter($_POST['name']);
	 $email = inputfilter($_POST['email']);
	 $phone = inputfilter($_POST['phone']);
	 $subject = inputfilter($_POST['subject']);
	 $message = inputfilter($_POST['message']);
	 $date = date("Y-m-d h:i:s");
	 
	 
     


     $sql = "INSERT INTO easycontact (name, email, phone, subject, message, date)
     VALUES ('$name', '$email', '$phone', '$subject', '$message', '$date')";

     if ($conn->query($sql) === TRUE) {
         echo "New record created successfully";
         } else {
         echo "Error: " . $sql . "<br>" . $conn->error;
    }


     $conn->close();
}else{
	header("Location: index.php"); // Redirect browser 
exit();
}






?>
<?php
require('include/function.php');
include('include/config.php');
?>

<html>
  <head>
     <title><?php echo $sitename;?></title>
	 <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	 <meta name="description" content="<?php echo $sitemeta;?>">
     <link href="css/bootstrap.css" rel="stylesheet">
	 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
     <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
     <script src="//cdnjs.cloudflare.com/ajax/libs/jquery-form-validator/2.3.26/jquery.form-validator.min.js"></script>
	 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <style>
     body{
	   background-color:#e9ebee;
     }
     .back{
	
	   margin: 100px auto;
       width: 50%;
       border: 1px solid #cbcbcb;
       padding: 10px 10px 10px 10px;
	   background-color:white;
     }
	 .alert-success
	 {
	   position: absolute;
	   width:100%;
       left: 0px;
       top: 0px;
       z-index: -1;
		 
	 }
	 .message{
		 width:100%;
		 height30px;
	 }
    </style>
    <script src="js/jquery-1.9.1.js"></script>
    <script>
      $(function () {

        $('form').on('submit', function (e) {

          e.preventDefault();

          $.ajax({
            type: 'post',
            url: 'send.php',
            data: $('form').serialize(),
            success: function () {
              $.notify = ('<div class="alert alert-success">'+'<center>Message send complete</center>'+'</div>');
              document.getElementById("complet").innerHTML = $.notify;
		      $("#complet").fadeOut(5000);
            }
          });
        });
      });
    </script>
	
  </head>

<body>
<nav class="navbar navbar-expand-md navbar-dark bg-dark">
      <a class="navbar-brand" href="index.php">EasyUser</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample04" aria-controls="navbarsExample04" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarsExample04">
        <ul class="navbar-nav mr-auto">
          <li class="nav-item active">
            <a class="nav-link" href="index.php">Home <span class="sr-only">(current)</span></a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="contact.php">Contact</a>
          </li>
          
        </ul>
        <ul class="nav navbar-nav navbar-right">
      <li><a href="register.php"><span class="glyphicon glyphicon-user"></span> Sign Up</a></li>
      <li><a href="login.php"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>
    </ul>
      </div>
    </nav>
	</br>
<div class="message"><p  id="complet"></p></div>
<div class="back">
    <form>
      
	  <div class="panel panel-success">
      <div class="panel-heading"><center><h1>EasyUser Contact</h1></center></div>
      <div class="panel-body">
	  
	  <div class="clearfix"></div>
        <div class="row">
         <div class="col-sm">
		 <div class="form-group">
             <label >Your name</label>
             <input type="text" name="name"  class="form-control" required="true">
          </div>
          <div class="form-group">
             <label >Email address</label>
             <input type="email" name="email" class="form-control" data-validation="email" required="true">
          </div>
          <div class="form-group">
             <label >Phone</label>
             <input type="text" name="phone" class="form-control"  required="true">
          </div>
        </div>
       <div class="col-sm">
	   <div class="form-group">
          <div class="form-group">
             <label >Subject</label>
             <input type="text" name="subject" class="form-control" required="true">
          </div>
        </div>
        <div class="form-group">
             <label >Message</label>
             <textarea class="form-control" name="message" required="true" rows="3"></textarea>
        </div>
       </div>
  
     </form>
  </div>
 <input type="submit" name="submit" value="Submit" class="btn btn-primary mb-2">

</div>
    </div>
</div>




</body>

</html>






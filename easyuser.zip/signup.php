<?php
require('include/function.php');
include('include/config.php');
?>
<html>
  <head>
     <title><?php echo $sitename;?></title>
	 <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	 <meta name="description" content="<?php echo $sitemeta;?>">
     <link href="css/bootstrap.css" rel="stylesheet">
	 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
     <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
     <script src="//cdnjs.cloudflare.com/ajax/libs/jquery-form-validator/2.3.26/jquery.form-validator.min.js"></script>
	 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	 </head>

<body>



<?php
if($sitereglive==1){
if(is_empty($_POST['outuser']) || is_empty($_POST['outmail']) || is_empty($_POST['outpass'])) {
            echo "All fields required";
        }else{
			    if(!valid_username($_POST['outuser'])){
				   echo "Username is not correct. Minimum 3 characters and A-z,0-9";
			    }else{
				      if (!valid_email($_POST['outmail'])){
					       echo "Email is not correct";
				      }else{
					         $username=inputfilter($_POST['outuser']);
							 $gender=inputfilter($_POST['gender']);
							 $avatar="img/avatar.png";
							 $ip=user_ip();
					         $email=inputfilter($_POST['outmail']);
					         $password=inputfilter(encryptIt($_POST['outpass']));
							 $date = date("Y-m-d h:i:s");
							 $sql = "SELECT * FROM easyuser WHERE email='".$email."'";
                                $result = $conn->query($sql);
                                  if ($result->num_rows > 0) {
                                  while($row = $result->fetch_assoc()) {
                                     echo '<center><div class="alert alert-danger" role="alert">
                                         Email is already exist!
                                         </div></center>';
                                               }
                                  } else {
					         $sql ="INSERT INTO easyuser (username, email, avatar, gender, password, ip, logedin ) 
							     VALUES ('$username', '$email', '$avatar','$gender', '$password', '$ip', '$date')" ;
								 if ($conn->query($sql) === TRUE) {
                                  echo '<div class="alert alert-success" role="alert">
                                           <center>Registration complet! Please wait. system automated redirect login page.</center>
                                        </div> 
										<meta http-equiv="refresh" content="3;URL=index.php" />';
                                   } else {
                                            echo "Error: " . $sql . "<br>" . $conn->error;
                                          }
  										   
				           }
			        }
			
		    }

}
$conn->close();
}
?>
</body>

</html>
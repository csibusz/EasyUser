<?php

if(isset($_POST) && isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
	
	include("include/config.php");  //include config file
	
	if(isset($_POST["page"])){
		$page_number = filter_var($_POST["page"], FILTER_SANITIZE_NUMBER_INT, FILTER_FLAG_STRIP_HIGH); //filter number
		if(!is_numeric($page_number)){die('Invalid page number!');} //incase of invalid page number
	}else{
		$page_number = 1; 
	}
	
	$results = $conn->query("SELECT COUNT(*) FROM easyuser");
	$get_total_rows = $results->fetch_row(); //hold total records in variable
	//break records into pages
	$total_pages = ceil($get_total_rows[0]/$item_per_page);
	
	//get starting position to fetch the records
	$page_position = (($page_number-1) * $item_per_page);
	

	//Limit our results within a specified range. 
	$results = $conn->prepare("SELECT id, username, email, gender, logedin FROM easyuser ORDER BY id ASC LIMIT $page_position, $item_per_page");
	$results->execute(); //Execute prepared Query
	$results->bind_result($id, $username, $email, $gender, $logedin); //bind variables to prepared statement
	
	//Display records fetched from database.
	echo '<table id="example" class="table table-striped table-bordered">
  <thead>
  
    <tr>
      <th scope="col">#</th>
      <th scope="col">User</th>
      <th scope="col">Email</th>
      <th scope="col">Gender</th>
	  <th scope="col">Sign up</th>
    </tr>
  </thead>
  <tbody>';
	while($results->fetch()){ //fetch values
		
		echo  '<tr>
      <th scope="row">'.$id.'</th>
      <td>'.$username.'</td>
      <td>'.$email.'</td>
      <td>'.$gender.'</td>
	  <td>'.$logedin.'</td>
    </tr>';
		
	}
	

	echo '</tbody>
</table>';echo '<div align="center">';
	
	echo paginate_function($item_per_page, $page_number, $get_total_rows[0], $total_pages);
	echo '</div>';
	
	exit;
}
################ pagination function #########################################
function paginate_function($item_per_page, $current_page, $total_records, $total_pages)
{
    $pagination = '';
    if($total_pages > 0 && $total_pages != 1 && $current_page <= $total_pages){ //verify total pages and current page number
        $pagination .= '<nav aria-label="Page navigation"><ul class="pagination">';
        
        $right_links    = $current_page + 3; 
        $previous       = $current_page - 3; //previous link 
        $next           = $current_page + 1; //next link
        $first_link     = true; //boolean var to decide our first link
        
        if($current_page > 1){
			$previous_link = ($previous==0)? 1: $previous;
			$valami=$current_page-1;
            $pagination .= '<li class="page-item"><a href="#" class="page-link" data-page="1" title="First">&laquo;</a></li>'; //first link
            $pagination .= '<li class="page-item"><a href="#" class="page-link" data-page="'.$valami.'" title="Previous">&lt;</a></li>'; //previous link
                for($i = ($current_page-2); $i < $current_page; $i++){ //Create left-hand side links
                    if($i > 0){
                        $pagination .= '<li class="page-item"><a href="#" data-page="'.$i.'" title="Page'.$i.'">'.$i.'</a></li>';
                    }
                }   
            $first_link = false; //set first link to false
        }
        
        if($first_link){ //if current active page is first link
            $pagination .= '<li class="page-item" "><a href="#" class="page-link"  >'.$current_page.'</a></li>';
        }elseif($current_page == $total_pages){ //if it's the last active link
            $pagination .= '<li class="page-item" "><a href="#" class="page-link"  >'.$current_page.'</a></li>';
        }else{ //regular current link
            $pagination .= '<li class="page-item""><a href="#" class="page-link"  >'.$current_page.'</a></li>';
        }
                
        for($i = $current_page+1; $i < $right_links ; $i++){ //create right-hand side links
            if($i<=$total_pages){
                $pagination .= '<li class="page-item"><a href="#" class="page-link" data-page="'.$i.'" title="Page '.$i.'">'.$i.'</a></li>';
            }
        }
        if($current_page < $total_pages){ 
				$next_link = ($i > $total_pages) ? $total_pages : $i;
                $pagination .= '<li class="page-item"><a href="#" class="page-link" data-page="'.$next_link.'" title="Next">&gt;</a></li>'; //next link
                $pagination .= '<li class="page-item"><a href="#"  class="page-link" data-page="'.$total_pages.'" title="Last">&raquo;</a></li>'; //last link
        }
        
        $pagination .= '</ul></nav>'; 
    }
    return $pagination; //return pagination links
}

?>


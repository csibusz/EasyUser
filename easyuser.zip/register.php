<?php
require('include/function.php');
include('include/config.php');
?>
<html>
  <head>
     <title><?php echo $sitename;?></title>
	 <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	 <meta name="description" content="<?php echo $sitemeta;?>">
     <link href="css/bootstrap.css" rel="stylesheet">
	 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
     <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
     <script src="//cdnjs.cloudflare.com/ajax/libs/jquery-form-validator/2.3.26/jquery.form-validator.min.js"></script>
	 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	 </head>

<body>
<nav class="navbar navbar-expand-md navbar-dark bg-dark">
      <a class="navbar-brand" href="index.php">EasyUser</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample04" aria-controls="navbarsExample04" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarsExample04">
        <ul class="navbar-nav mr-auto">
          <li class="nav-item active">
            <a class="nav-link" href="index.php">Home <span class="sr-only">(current)</span></a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="contact.php">Contact</a>
          </li>
          
        </ul>
        <ul class="nav navbar-nav navbar-right">
      <li><a href="register.php"><span class="glyphicon glyphicon-user"></span> Sign Up</a></li>
      <li><a href="login.php"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>
    </ul>
      </div>
    </nav>
	</br>
	<?php
	     if($sitereglive==1){
	?>
	<div class="container">
	<div class="row">
         
             <div class="col">
      
    </div>
    <div class="col-6">
     <div class="panel panel-info">
      <div class="panel-heading"><center><h2 class="form-signin-heading">Registration</h2></center></div>
      <div class="panel-body">
    
			 <form class="form-signin" method="post" action="signup.php">
                
			   <label >Username</label>
                  <input type="text" id="inputEmail" name="outuser" class="form-control" placeholder="Username" required="true" autofocus="">
				  </br>
               <label >Email address</label>
                  <input type="email" id="inputEmail" name="outmail" class="form-control" data-validation="email" placeholder="Email address" required="true" autofocus="">
				  </br>
				  <div class="form-group">
                  <label  >Gender:</label>
                  <select style="height:auto" class="form-control" name="gender">
                    <option value="Male">Male</option>
                    <option value="Famale">Famale</option>
                    </select>
               </div>
			   </br>
               <label >Password</label>
                  <input type="password" id="inputPassword" name="outpass" class="form-control" placeholder="Password" required="true">
				  </br>
               <div class="checkbox">
               
               </div>
                  <button class="btn btn-lg btn-primary btn-block" type="submit">Sign up</button>
             </form>
			 </div>
    </div>
         </div>
    <div class="col">
      
    </div>
     </div>
</div>
<?php
		 }else{
			 echo"<center><h1><font color='red'>Registration closed</font></h1></center>";
		 }
?>
</body>

</html>
<?php
session_start();
require('include/function.php');
include('include/config.php');

if(isset($_POST['inmail']) || isset($_POST['inpass']) ) {
     if (!valid_email($_POST['inmail'])){
		echo '<div class="alert alert-success" role="alert">
           <center>Email is incorrect</center></div>';
	}else{
		$email=secure($_POST['inmail']);
		$password=secure($_POST['inpass']);
		$sql = "SELECT * FROM easyuser WHERE email='".$email."'";
                $result = $conn->query($sql);
                     if ($result->num_rows > 0) {
                         while($row = $result->fetch_assoc()) {
                            $pass=decryptIt($row['password']);
							$username=$row['username'];
							$id=$row['id'];
							$admin=$row['admin'];
							$mail=$row['email'];
							if($password==$pass){
								$_SESSION['login'] = true;
                                $_SESSION['username'] = $username;
								$_SESSION['id'] = $id;
								$_SESSION['email']=$mail;
								$_SESSION['superuser'] = $admin;
								$_SESSION['pass']=$pass;
								
								header('Location: home.php');
							}else{
							 echo '<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Password error</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true"></span>
        </button>
      </div>
      <div class="modal-body">
        Password is inncorrect
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        
      </div>
    </div>
  </div>
</div>';
						 }
                         }
					 }else{
						 echo'<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Not found</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true"></span>
        </button>
      </div>
      <div class="modal-body">
        Email is not found database
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        
      </div>
    </div>
  </div>
</div>';
					 }	 
	}
}
	

?>



<html>
  <head>
     <title><?php echo $sitename;?></title>
	 <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	 <meta name="description" content="<?php echo $sitemeta;?>">
     <link href="css/bootstrap.css" rel="stylesheet">
	 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
     <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
     <script src="//cdnjs.cloudflare.com/ajax/libs/jquery-form-validator/2.3.26/jquery.form-validator.min.js"></script>
	 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	 </head>
<script type="text/javascript">
    $(window).on('load',function(){
        $('#myModal').modal('show');
    });
</script>
<body>
<nav class="navbar navbar-expand-md navbar-dark bg-dark">
      <a class="navbar-brand" href="index.php">EasyUser</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample04" aria-controls="navbarsExample04" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarsExample04">
        <ul class="navbar-nav mr-auto">
          <li class="nav-item active">
            <a class="nav-link" href="index.php">Home <span class="sr-only">(current)</span></a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="contact.php">Contact</a>
          </li>
          
        </ul>
        <ul class="nav navbar-nav navbar-right">
      <li class="nav-item"><a href="register.php"><span class="glyphicon glyphicon-user"></span> Sign Up</a></li>
      <li class="nav-item"><a href="login.php"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>
    </ul>
      </div>
    </nav>
	</br>
<div class="container">
	<div class="row">
         <div class="col">
      
    </div>
    <div class="col-6">
	<div class="panel panel-info">
      <div class="panel-heading"><center><h2 class="form-signin-heading">Please sign in</h2></center></div>
      <div class="panel-body">
             <form class="form-signin" method="post" action="">
                
               <label for="inputEmail" class="sr-only">Email address</label>
                  <input type="email" id="inputEmail" name="inmail" class="form-control" placeholder="Email address" required="" autofocus="">
				  </br>
               <label for="inputPassword" class="sr-only">Password</label>
                  <input type="password" id="inputPassword" name="inpass" class="form-control" placeholder="Password" required="">
               <div class="checkbox">
               <label>
                  <input type="checkbox" value="remember-me"> Remember me
               </label>
               </div>
                  <button class="btn btn-lg btn-primary btn-block" type="submit">Sign in</button>
             </form>
			 </div>
    </div>
			</div>
    <div class="col">
      
    </div> 
         
     </div>
</div>
</body>

</html>
<?php
session_start();
include 'include/config.php'; 
if ( !isset($_SESSION['login']) || $_SESSION['login'] !== true) {

if(empty($_SESSION['access_token']) || empty($_SESSION['access_token']['oauth_token']) || empty($_SESSION['access_token']['oauth_token_secret'])){

if ( !isset($_SESSION['token'])) {



 header('Location: index.php');

exit;

}
}
}



?>
<html>
  <head>
     <title><?php echo $sitename;?></title>
	 <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	 <meta name="description" content="<?php echo $sitemeta;?>">
     <link href="css/bootstrap.css" rel="stylesheet">
	 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
     <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
     <script src="//cdnjs.cloudflare.com/ajax/libs/jquery-form-validator/2.3.26/jquery.form-validator.min.js"></script>
	 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	 </head>
<style>
.count{
	font-size: 20px;
    line-height: 47px;
    font-weight: 600;
	color: #73879C;
}

</style>
<body>
<nav class="navbar navbar-expand-md navbar-dark bg-dark">
      <a class="navbar-brand" href="home.php">EasyUser</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample04" aria-controls="navbarsExample04" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarsExample04">
        <ul class="navbar-nav mr-auto">
          <li class="nav-item active">
            <a class="nav-link" href="home.php">Home <span class="sr-only">(current)</span></a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="contact.php">Contact</a>
          </li>
          
        </ul>
        <ul class="nav navbar-nav navbar-right">
		<?php  if(($_SESSION['superuser'])==1){echo'<li><a href="admin.php"><span class="glyphicon glyphicon-home"></span>Admin</a></li>';}  ?>
		<li><a href="settings.php"><span class="glyphicon glyphicon-cog"></span> Settings</a></li>
      <li><a href="log.php"><span class="glyphicon glyphicon-user"></span> Logout</a></li>
      
    </ul>
      </div>
    </nav>
	</br>
	
<div class="container">

	<div class="row">
         <div class="col-8"><?php
	     $sql = "SELECT * FROM easynews WHERE location=0 ";
                                $result = $conn->query($sql);
                                  if ($result->num_rows > 0) {
                                  while($row = $result->fetch_assoc()) {
								  if($row['location']==0){
									  
									  echo'<div class="panel-group"><h2 class="form-signin-heading">News Content</h2>
		      <div class="panel panel-primary">
      <div class="panel-heading">'.$row['title'].' </div>
      <div class="panel-body">
	  '.$row['news'].'
	  <hr>
	  <div style="float:left"><p class="card-text"><small class="text-muted">Created by : '.$row['creatorname'].' </small></p></div><div style="float:right"><p class="card-text"><small class="text-muted">Created date : '.$row['created'].' </small></p></div>
	  </div>
    </div>
		 </div> ';
								  }else{
									  echo'<div class="panel-group"><h2 class="form-signin-heading">News Content</h2>
		      <div class="panel panel-primary">
      <div class="panel-heading">No news</div>
      <div class="panel-body">
	  Please add news content...
	  <hr>
	  <div style="float:left"><p class="card-text"><small class="text-muted">Created by : ..... </small></p></div><div style="float:right"><p class="card-text"><small class="text-muted">Created date : ..... </small></p></div>
	  </div>
    </div>
		 </div> ';
								  }
								  }
								  
	}
	  ?>
	  <div class="card-group">
		 <?php
	     $sql = "SELECT * FROM easyuser ORDER BY id DESC LIMIT 5";
                                $result = $conn->query($sql);
                                  if ($result->num_rows > 0) {
                                  while($row = $result->fetch_assoc()) {
									  
									  echo'
  <div class="card" style="height:380x">
    <img class="img-thumbnail " style="min-height:150px" src="'.$row['avatar'].'"  alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title count">'.$row['username'].'</h5>
      <p class="card-text">Gender: '.$row['gender'].'</p>
      <p class="card-text"><small class="text-muted">Registered '.$row['logedin'].'</small></p>
    </div>
  </div>';
								  }
								  }
	  ?>
	  </div>
		 </div>
         <div class="col-4">
		 <?php $ip=user_ip();
	     $sql = "SELECT * FROM easyuser WHERE id='".$_SESSION['id']."'";
                                $result = $conn->query($sql);
                                  if ($result->num_rows > 0) {
                                  while($row = $result->fetch_assoc()) {
									 
									  
									  echo'<div class="card mb-3">
  <img class="card-img-top" src="'.$row['avatar'].'" alt="Card image cap">
  <div class="card-body">
    <h5 class="card-title count">'.$row['username'].'</h5>
    <p class="card-text"><a  class="btn btn-success" href="settings.php" role="button"><span class="glyphicon glyphicon-cog"></span> Settings</a></p>
    <p class="card-text"><small class="text-muted">Registration '.$row['logedin'].'</small></p>
	<p class="card-text"><small class="text-muted">Current ip:  '.$ip.'</small></p>
  </div>
</div>';
								  
								  }
								  
	}
	  ?>
		 
		 <?php
	     $sql = "SELECT * FROM easynews WHERE location=1";
                                $result = $conn->query($sql);
                                  if ($result->num_rows > 0) {
                                  while($row = $result->fetch_assoc()) {
									 if($row['location']==1){
									  
									  echo'<div class="panel-group"><h2 class="form-signin-heading">News sidebar</h2>
		      <div class="panel panel-primary">
      <div class="panel-heading">'.$row['title'].' </div>
      <div class="panel-body">
	  '.$row['news'].'
	  <hr>
	  <div style="float:left"><p class="card-text"><small class="text-muted">Created by : '.$row['creatorname'].' </small></p></div><div style="float:right"><p class="card-text"><small class="text-muted">Created date : '.$row['created'].' </small></p></div>
	  </div>
    </div>
		 </div> ';
								  }else{
									  echo'<div class="panel-group"><h2 class="form-signin-heading">News 1</h2>
		      <div class="panel panel-primary">
      <div class="panel-heading">No news</div>
      <div class="panel-body">
	  Please add news content...
	  <hr>
	  <div style="float:left"><p class="card-text"><small class="text-muted">Created by : ..... </small></p></div><div style="float:right"><p class="card-text"><small class="text-muted">Created date : ..... </small></p></div>
	  </div>
    </div>
		 </div> ';
								  }
								  }
								  
	}
	  ?>
		        
		 
		 
		 
		 
		 
		 
             
			 
			 
         </div>
     </div>
</div>
<nav class="navbar sticky-top navbar-light bg-faded">
  <a class="" href="">© <?php echo $sitename ; ?> <?php echo date("Y");?></a>
</nav>
</body>

</html>
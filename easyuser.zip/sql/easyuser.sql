-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Gép: 127.0.0.1
-- Létrehozás ideje: 2018. Ápr 02. 10:26
-- Kiszolgáló verziója: 10.1.31-MariaDB
-- PHP verzió: 5.6.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Adatbázis: `contact-codecanyon`
--

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `easycontact`
--

CREATE TABLE `easycontact` (
  `id` int(100) NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_hungarian_ci NOT NULL,
  `email` varchar(100) COLLATE utf8mb4_hungarian_ci NOT NULL,
  `phone` varchar(100) COLLATE utf8mb4_hungarian_ci NOT NULL,
  `subject` varchar(100) COLLATE utf8mb4_hungarian_ci NOT NULL,
  `message` varchar(500) COLLATE utf8mb4_hungarian_ci NOT NULL,
  `date` varchar(100) COLLATE utf8mb4_hungarian_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_hungarian_ci;

--
-- A tábla adatainak kiíratása `easycontact`
--

INSERT INTO `easycontact` (`id`, `name`, `email`, `phone`, `subject`, `message`, `date`) VALUES
(1, 'Pál Csaba', 'stargate1983116@gmail.com', '203510446', 'xzjkcukd', 'cukcucu', '2018-03-30 04:44:46'),
(2, 'Pál Csaba', 'stargate1983116@gmail.com', '203510446', 'rgftrhtr', 'hrtrhrthrth', '2018-03-30 06:28:20'),
(3, 'Pál Csaba', 'stargate1983116@gmail.com', '203510446', 'yryrh', 'yyh', '2018-03-30 12:15:09'),
(4, 'Pál Csaba', 'stargate1983116@gmail.com', '203510446', 'yryrh', 'yyh', '2018-03-31 01:00:15'),
(5, 'Pál Csaba', 'stargate1983116@gmail.com', '203510446', 'yryrh', 'yyh', '2018-03-31 01:00:17'),
(6, 'Pál Csaba', 'stargate1983116@gmail.com', '203510446', '4u6jde6', 'uwe6ue', '2018-03-31 01:00:23'),
(7, 'Pál Csaba', 'stargate1983116@gmail.com', '203510446', '4u6jde6', 'uwe6ue', '2018-03-31 01:00:31'),
(8, 'Pál Csaba', 'stargate1983116@gmail.com', '203510446', 'ft6ud', 'ide5', '2018-03-31 01:00:41'),
(9, 'Pál Csaba', 'stargate1983116@gmail.com', '203510446', 'xmzj', 'sdzmjdjz', '2018-03-31 01:14:24'),
(10, 'Pál Csaba', 'stargate1983116@gmail.com', '203510446', 'xftjxst', 'njxstnjxsr', '2018-04-01 01:52:02');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `easylog`
--

CREATE TABLE `easylog` (
  `id` int(11) NOT NULL,
  `os` varchar(100) COLLATE utf8mb4_hungarian_ci NOT NULL,
  `browser` varchar(100) COLLATE utf8mb4_hungarian_ci NOT NULL,
  `date` varchar(100) COLLATE utf8mb4_hungarian_ci NOT NULL,
  `ip` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_hungarian_ci;

--
-- A tábla adatainak kiíratása `easylog`
--

INSERT INTO `easylog` (`id`, `os`, `browser`, `date`, `ip`) VALUES
(1, 'Windows 7', 'Chrome', '2018-04-01 12:40:44', 0),
(2, 'Windows 7', 'Chrome', '2018-04-01 12:40:53', 0),
(3, 'Windows 7', 'Chrome', '2018-04-01 12:40:54', 0),
(4, 'Windows 7', 'Chrome', '2018-04-01 12:43:39', 0),
(5, 'Windows 7', 'Chrome', '2018-04-01 12:43:45', 0),
(6, 'Windows 7', 'Chrome', '2018-04-01 12:43:58', 0),
(7, 'Windows 7', 'Chrome', '2018-04-01 12:44:19', 0),
(8, 'Windows 7', 'Chrome', '2018-04-01 12:44:22', 0),
(9, 'Windows 7', 'Chrome', '2018-04-01 12:44:23', 0),
(10, 'Android', 'Handheld Browser', '2018-04-01 03:42:12', 192168),
(11, 'Windows 7', 'Chrome', '2018-04-02 02:19:30', 0),
(12, 'Windows 7', 'Chrome', '2018-04-02 02:33:36', 0),
(13, 'Windows 7', 'Chrome', '2018-04-02 02:34:00', 0),
(14, 'Windows 7', 'Chrome', '2018-04-02 02:34:27', 0),
(15, 'Windows 7', 'Chrome', '2018-04-02 03:11:27', 0),
(16, 'Windows 7', 'Chrome', '2018-04-02 03:12:28', 0),
(17, 'Windows 7', 'Chrome', '2018-04-02 03:12:30', 0),
(18, 'Windows 7', 'Chrome', '2018-04-02 03:15:17', 0),
(19, 'Windows 7', 'Chrome', '2018-04-02 03:17:22', 0),
(20, 'Windows 7', 'Chrome', '2018-04-02 03:21:24', 0),
(21, 'Windows 7', 'Chrome', '2018-04-02 03:22:34', 0),
(22, 'Windows 7', 'Chrome', '2018-04-02 03:41:44', 0),
(23, 'Windows 7', 'Chrome', '2018-04-02 03:47:22', 0),
(24, 'Windows 7', 'Chrome', '2018-04-02 03:57:11', 0);

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `easynews`
--

CREATE TABLE `easynews` (
  `id` int(11) NOT NULL,
  `creatorid` varchar(100) COLLATE utf8mb4_hungarian_ci NOT NULL,
  `creatorname` varchar(100) COLLATE utf8mb4_hungarian_ci NOT NULL,
  `title` varchar(100) COLLATE utf8mb4_hungarian_ci NOT NULL,
  `news` varchar(1000) COLLATE utf8mb4_hungarian_ci NOT NULL,
  `created` varchar(100) COLLATE utf8mb4_hungarian_ci NOT NULL,
  `activ` varchar(100) COLLATE utf8mb4_hungarian_ci NOT NULL,
  `location` varchar(100) COLLATE utf8mb4_hungarian_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_hungarian_ci;

--
-- A tábla adatainak kiíratása `easynews`
--

INSERT INTO `easynews` (`id`, `creatorid`, `creatorname`, `title`, `news`, `created`, `activ`, `location`) VALUES
(1, '25', 'csibusz', 'What is Lorem Ipsum?', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.', '2018-04-01 10:49:15', '1', '1'),
(2, '10', 'csibusz', 'Why do we use it?', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).', '2018-04-02 03:00:29', '1', '0');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `easysettings`
--

CREATE TABLE `easysettings` (
  `id` int(11) NOT NULL,
  `websitename` varchar(100) COLLATE utf8mb4_hungarian_ci NOT NULL,
  `meta` varchar(500) COLLATE utf8mb4_hungarian_ci NOT NULL,
  `reglive` varchar(100) COLLATE utf8mb4_hungarian_ci NOT NULL,
  `email` varchar(100) COLLATE utf8mb4_hungarian_ci NOT NULL,
  `term` varchar(1000) COLLATE utf8mb4_hungarian_ci NOT NULL,
  `regmail` varchar(100) COLLATE utf8mb4_hungarian_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_hungarian_ci;

--
-- A tábla adatainak kiíratása `easysettings`
--

INSERT INTO `easysettings` (`id`, `websitename`, `meta`, `reglive`, `email`, `term`, `regmail`) VALUES
(1, 'EasyUser v 1.21', 'EasyUser php and mysql script', '0', 'easy@user.com', 'Term Of Use', '0');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `easyuser`
--

CREATE TABLE `easyuser` (
  `id` int(11) NOT NULL,
  `username` varchar(100) COLLATE utf8mb4_hungarian_ci NOT NULL,
  `email` varchar(100) COLLATE utf8mb4_hungarian_ci NOT NULL,
  `avatar` varchar(100) COLLATE utf8mb4_hungarian_ci NOT NULL,
  `gender` varchar(100) COLLATE utf8mb4_hungarian_ci NOT NULL,
  `password` varchar(100) COLLATE utf8mb4_hungarian_ci NOT NULL,
  `ip` varchar(100) COLLATE utf8mb4_hungarian_ci NOT NULL,
  `logedin` varchar(100) COLLATE utf8mb4_hungarian_ci NOT NULL,
  `admin` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_hungarian_ci;

--
-- A tábla adatainak kiíratása `easyuser`
--

INSERT INTO `easyuser` (`id`, `username`, `email`, `avatar`, `gender`, `password`, `ip`, `logedin`, `admin`) VALUES
(8, 'Ákos', 'akos@akos.com', 'img/avatar.png', 'male', 'uFM9xGTZ+JLj6644oM7z1wrRxvLir4MM1iK/eL+Kc8U=', '::1', '2018-03-31 12:28:03', 0),
(9, 'zoli', 'kjsgksg@sergwse.com', 'img/avatar.png', 'male', 'uFM9xGTZ+JLj6644oM7z1wrRxvLir4MM1iK/eL+Kc8U=', '::1', '2018-03-31 12:30:08', 0),
(10, 'admin', 'admin@admin.com', 'upload/b0943b73c6762d0cead5c87fb8e8fb61.jpg', 'famale', 'uFM9xGTZ+JLj6644oM7z1wrRxvLir4MM1iK/eL+Kc8U=', '::1', '2018-03-31 03:56:50', 1),
(26, 'Lala', 'admin@gmail.com', 'img/avatar.png', 'male', 'uFM9xGTZ+JLj6644oM7z1wrRxvLir4MM1iK/eL+Kc8U=', '::1', '2018-04-01 11:20:35', 0),
(27, 'user', 'user@user.com', 'img/avatar.png', 'Famale', 'uFM9xGTZ+JLj6644oM7z1wrRxvLir4MM1iK/eL+Kc8U=', '::1', '2018-04-01 11:22:07', 0);

--
-- Indexek a kiírt táblákhoz
--

--
-- A tábla indexei `easycontact`
--
ALTER TABLE `easycontact`
  ADD PRIMARY KEY (`id`);

--
-- A tábla indexei `easylog`
--
ALTER TABLE `easylog`
  ADD PRIMARY KEY (`id`);

--
-- A tábla indexei `easynews`
--
ALTER TABLE `easynews`
  ADD PRIMARY KEY (`id`);

--
-- A tábla indexei `easysettings`
--
ALTER TABLE `easysettings`
  ADD PRIMARY KEY (`id`);

--
-- A tábla indexei `easyuser`
--
ALTER TABLE `easyuser`
  ADD PRIMARY KEY (`id`);

--
-- A kiírt táblák AUTO_INCREMENT értéke
--

--
-- AUTO_INCREMENT a táblához `easycontact`
--
ALTER TABLE `easycontact`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT a táblához `easylog`
--
ALTER TABLE `easylog`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT a táblához `easynews`
--
ALTER TABLE `easynews`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT a táblához `easysettings`
--
ALTER TABLE `easysettings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT a táblához `easyuser`
--
ALTER TABLE `easyuser`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

<?php
session_start();
require('include/function.php');
include('include/config.php');
if ( !isset($_SESSION['login']) || $_SESSION['login'] !== true) {

if(empty($_SESSION['access_token']) || empty($_SESSION['access_token']['oauth_token']) || empty($_SESSION['access_token']['oauth_token_secret'])){

if ( !isset($_SESSION['token'])) {



 header('Location: index.php');

exit;

}
}
}
if (!isset($_SESSION['superuser'])) {
    header('Location: index.php');
}


?>
<html>
  <head>
     <title><?php echo $sitename;?></title>
	 <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	 <meta name="description" content="<?php echo $sitemeta;?>">
     <link href="css/bootstrap.css" rel="stylesheet">
	 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
     <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
     <script src="//cdnjs.cloudflare.com/ajax/libs/jquery-form-validator/2.3.26/jquery.form-validator.min.js"></script>
	 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	 
	 <script type="text/javascript">
$(document).ready(function() {
	$("#results" ).load( "pagination.php"); //load initial records
	
	//executes code below when user click on pagination links
	$("#results").on( "click", ".pagination a", function (e){
		e.preventDefault();
		$(".loading-div").show(); //show loading element
		var page = $(this).attr("data-page"); //get page number from link
		$("#results").load("pagination.php",{"page":page}, function(){ //get content from PHP page
			$(".loading-div").hide(); //once done, hide loading element
		});
		
	});
});
</script>
	 </head>
<style>
.count{
	font-size: 30px;
    line-height: 47px;
    font-weight: 600;
	color: #73879C;
}
.admin{
	margin-right: 5px;
    margin-bottom: 0;
    margin-left: 5px;
	width:22%;
}

.loading-div{
	position: absolute;
	top: 0;
	left: 0;
	width: 100%;
	height: 100%;
	background: rgba(0, 0, 0, 0.56);
	z-index: 999;
	display:none;
}
.loading-div img {
	margin-top: 20%;
	margin-left: 50%;
}

}
</style>
<body>
<nav class="navbar navbar-expand-md navbar-dark bg-dark">
      <a class="navbar-brand" href="home.php">EasyUser</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample04" aria-controls="navbarsExample04" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarsExample04">
        <ul class="navbar-nav mr-auto">
          <li class="nav-item active">
            <a class="nav-link" href="home.php">Home <span class="sr-only">(current)</span></a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="contact.php">Contact</a>
          </li>
          
        </ul>
        <ul class="nav navbar-nav navbar-right">
		<?php  if(($_SESSION['superuser'])==1){echo'<li><a href="admin.php"><span class="glyphicon glyphicon-home"></span>Admin</a></li>';}  ?>
		<li><a href="settings.php"><span class="glyphicon glyphicon-cog"></span> Settings</a></li>
      <li><a href="log.php"><span class="glyphicon glyphicon-user"></span> Logout</a></li>
      
    </ul>
      </div>
    </nav>
	</br>
<div class="container">
	<div class="row">
	     <div class="col-6 col-md-4"><ul class="navbar-nav navbar-sidenav " id="exampleAccordion">
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="" data-original-title="Dashboard">
          <a class="nav-link" href="admin.php">
            <i class="fa fa-fw fa-dashboard"></i>
            <span class="nav-link-text">Dashboard</span>
          </a>
        </li>
        
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="" data-original-title="Tables">
          <a class="nav-link" href="admin_users.php">
            <i class="fa fa-fw fa-table"></i>
            <span class="nav-link-text">Users</span>
          </a>
        </li>
        
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="" data-original-title="Link">
          <a class="nav-link" href="admin_news.php">
            <i class="fa fa-fw fa-link"></i>
            <span class="nav-link-text">News</span>
          </a>
        </li>
		<li class="nav-item" data-toggle="tooltip" data-placement="right" title="" data-original-title="Link">
          <a class="nav-link" href="admin_settings.php">
            <i class="fa fa-fw fa-link"></i>
            <span class="nav-link-text">Website settings</span>
          </a>
        </li>
      </ul></div>
	     <div class="col-12 col-md-8">
		 <div class="card-deck">
  
    <div class="panel panel-primary admin">
      <div class="panel-heading"><i class="glyphicon glyphicon-user"></i> Total Users</div>
      <div class="panel-body"><div class="count"><?php
	     $sql = "SELECT * FROM easyuser ORDER BY id";
		 if ($result=mysqli_query($conn,$sql))
            {
               $rowcount=mysqli_num_rows($result);
                printf("%d \n",$rowcount);
                 mysqli_free_result($result);
            }
	  ?></div></div>
    </div>
  
  
    <div class="panel panel-success admin">
      <div class="panel-heading"><i class="glyphicon glyphicon-user"></i> Total Males</div>
      <div class="panel-body"><div class="count"><?php
	     $sql = "SELECT * FROM easyuser WHERE gender='male'";
		 if ($result=mysqli_query($conn,$sql))
            {
               $rowcount=mysqli_num_rows($result);
                printf("%d \n",$rowcount);
                 mysqli_free_result($result);
            }
	  ?></div></div>
    </div>
  
  
    <div class="panel panel-danger admin">
      <div class="panel-heading"><i class="glyphicon glyphicon-user"></i> Total Females</div>
      <div class="panel-body"><div class="count"><?php
	     $sql = "SELECT * FROM easyuser WHERE gender='famale'";
		 if ($result=mysqli_query($conn,$sql))
            {
               $rowcount=mysqli_num_rows($result);
                printf("%d \n",$rowcount);
                 mysqli_free_result($result);
            }
	  ?></div></div>
    </div>
  
  
    <div class="panel panel-warning admin">
      <div class="panel-heading"><i class="glyphicon glyphicon-envelope"></i> New message</div>
      <div class="panel-body"><div class="count"><?php
	     $sql = "SELECT * FROM easycontact ORDER BY id";
		 if ($result=mysqli_query($conn,$sql))
            {
               $rowcount=mysqli_num_rows($result);
                printf("%d \n",$rowcount);
                 mysqli_free_result($result);
            }
	  ?></div></div>
	  
    </div>
	
	
</div>
</br></br></br>
		<div class="panel panel-default">
  <div class="panel-heading">Users</div>
  <div class="panel-body">
  <div class="loading-div"><img src="ajax-loader.gif" ></div>
<div id="results"><!-- content will be loaded here --></div>

</div>
</div> 
		 
		 
		 </div>
  
    </div>
</div>
</body>

</html>
<?php



    

?>
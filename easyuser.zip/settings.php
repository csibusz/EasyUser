<?php
session_start();
require('include/function.php');
include('include/config.php');
if ( !isset($_SESSION['login']) || $_SESSION['login'] !== true) {

if(empty($_SESSION['access_token']) || empty($_SESSION['access_token']['oauth_token']) || empty($_SESSION['access_token']['oauth_token_secret'])){

if ( !isset($_SESSION['token'])) {



 header('Location: index.php');

exit;

}
}
}
// User general settings update
if(isset($_POST['edituser']) || isset($_POST['editmail']) || isset($_POST['editpass'])) {
            
        
			    if(!valid_username($_POST['edituser'])){
				   echo "Username is not correct. Minimum 3 characters and A-z,0-9";
			    }else{
				      if (!valid_email($_POST['editmail'])){
					       echo "Email is not correct";
				      }else{
					         $username=inputfilter($_POST['edituser']);
							 $ip=user_ip();
					         $email=inputfilter($_POST['editmail']);
					         $password=inputfilter(encryptIt($_POST['editpass']));
							 $date = date("Y-m-d h:i:s");
							 $sql = "SELECT * FROM easyuser WHERE id=".$_SESSION['id']."";
                                $result = $conn->query($sql);
                                  if ($result->num_rows > 0) {
                                  while($row = $result->fetch_assoc()) {
                                     $sql ="UPDATE  easyuser SET username='$username', email='$email', password='$password' WHERE id=".$_SESSION['id']."" ;
								 if ($conn->query($sql) === TRUE) {
                                  
                                   } else {
                                            echo "Error: " . $sql . "<br>" . $conn->error;
                                          }
                                               }
                                  } 
					         
  										   
				           }
			        }
			
		    }





//user avatar update
class uploader{
private $type = array("jpg","jpeg","gif","png"),$width = 250,$height = 250,$info = '',$error='';
 function __construct($file,$dir,$newfile){
 $this->file = $file;
 $this->dir = $dir;
 $this->newfile = $newfile;
 @error_reporting(0);
 }
 public function upload(){
 $ext = explode(".",$this->file['name']);
 $ext = strtolower(end($ext));
 
 if(file_exists($this->dir.$this->file['name'])){
 $this->error .= "<div class='text-center'><b>Filename alredy exist!</b></div>";
 return false;
 }
 if (!in_array($ext,$this->type)){
 $this->error .= "<div class='text-center'><b>File Format not supported</b></div>";
 return false;
 }
 list($imwidth,$imheight) = @getimagesize($this->file['tmp_name']);
 
 $hx = (100 / ($imwidth / $this->width)) * .01;
 $hx = round ($imheight * $hx);
 
 if ($hx < $this->height) {
 $this->height = (100 / ($imwidth / $this->width)) * .01;
 $this->height = round ($imheight * $this->height);
 } else {
 $this->width = (100 / ($imheight / $this->height)) * .01;
 $this->width = round ($imwidth * $this->width);
 }
 $image = @imagecreatetruecolor($this->width, $this->height);
 if($ext == "jpg" || $ext == "jpeg") {
 $im = @imagecreatefromjpeg ($this->file['tmp_name']);
 } else if($ext == "gif") {
 $im = @imagecreatefromgif ($this->file['tmp_name']);
 } else if($ext == "png") {
 $im = @imagecreatefrompng ($this->file['tmp_name']);
 }
 
 if(@imagecopyresampled($image, $im, 0, 0, 0, 0, $this->width, $this->height, $imwidth, $imheight)){
 $this->info .= '<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Avatar upload</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true"></span>
        </button>
      </div>
      <div class="modal-body">
        Avatar upload succesfull
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        
      </div>
    </div>
  </div>
</div>';
 }

 if($ext == "jpg" || $ext == "jpeg") {
 @imagejpeg($image, $this->dir.$this->newfile, 100);
 } else if($ext == "gif") {
 @imagegif ($image, $this->dir.$this->newfile);
 } else if($ext == "png") {
 @imagepng ($image, $this->dir.$this->newfile, 0);
 }
 
 @imagedestroy($im);
 return $im;
 
 }
 
 public function getInfo(){
 return $this->info;
 }
 
 public function getError(){
 if(empty($this->error))
 {$this->error = "<div class='text-center'><b>Unknown error! Your request cannot complete now!</b></div>";}
 return $this->error;
 }
 
 public static function e($e)
 {
 echo $e;
 }
 
}

if(isset($_FILES['file'])) {
$origname = $_FILES['file']['name'];
$ext = explode(".", $origname);
$extension = end($ext);
$md5 = md5(time()).md5($origname);
$uplaodfile = md5($md5).'.'.$extension;

$dir = "upload";
if (!is_dir($dir))
{
 mkdir($dir, 0755);
}
$uploader = new uploader($_FILES['file'],$dir.'/',$uplaodfile);

$uploader->upload();
$ok = $uploader->getInfo();
if(!empty($ok))
{
$avatar = $dir . '/' . $uplaodfile;
$uploaded= $uploader->getInfo();




$sql ="UPDATE easyuser SET avatar='$avatar' WHERE id=".$_SESSION['id']." " ;
								 if ($conn->query($sql) === TRUE) {
                                  
                                   } else {
                                            echo "Error: " . $sql . "<br>" . $conn->error;
                                          }



uploader::e($uploaded);
}
else
{
$uploaded = $uploader->getError();
uploader::e($uploaded);
}
}

?>
<html>
  <head>
     <title><?php echo $sitename;?></title>
	 <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	 <meta name="description" content="<?php echo $sitemeta;?>">
     <link href="css/bootstrap.css" rel="stylesheet">
	 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
     <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
     <script src="//cdnjs.cloudflare.com/ajax/libs/jquery-form-validator/2.3.26/jquery.form-validator.min.js"></script>
	 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	 <script src="http://code.jquery.com/jquery-1.9.1.js"></script>
    <script>
      $(function () {

        $('#form').on('submit', function (e) {

          e.preventDefault();

          $.ajax({
            type: 'post',
            url: 'include/change_user.php',
            data: $('form').serialize(),
			
            success: function handleData(data) {
                     $('#shop').append(data) ; 
	                 }

          });

        });

      });
	  function getData() {
    $.ajax({
        url : 'include/change_user.php',
        type: 'POST',
		dataType: 'html',
  data: content,
        success : handleData
    })
}


$(document).ready(function (e) {
    $('#upload').on('submit',(function(e) {
        e.preventDefault();
        var formData = new FormData(this);

        $.ajax({
            type:'POST',
            url: $(this).attr('include/upload.class.php'),
            data:formData,
            cache:false,
            contentType: false,
            processData: false,
            success:function handleData(data) {
                     $('#up').append('<div class="alert alert-success">'+'<center>Image upload complet</center>'+'</div>') ; 
	                 }
,
            error: function(data){
                console.log("error");
                console.log(data);
            }
        });
    }));

    $("#ImageBrowse").on("change", function() {
        $("#upload").submit();
    });
});
    </script>
	
	 </head>
<script type="text/javascript">
    $(window).on('load',function(){
        $('#myModal').modal('show');
    });
</script>

<body>
<nav class="navbar navbar-expand-md navbar-dark bg-dark">
      <a class="navbar-brand" href="index.php">EasyUser</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample04" aria-controls="navbarsExample04" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarsExample04">
        <ul class="navbar-nav mr-auto">
          <li class="nav-item active">
            <a class="nav-link" href="index.php">Home <span class="sr-only">(current)</span></a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="contact.php">Contact</a>
          </li>
          
        </ul>
        <ul class="nav navbar-nav navbar-right">
		<?php  if(($_SESSION['superuser'])==1){echo'<li><a href="admin.php"><span class="glyphicon glyphicon-home"></span>Admin</a></li>';}  ?>
		<li><a href="settings.php"><span class="glyphicon glyphicon-cog"></span> Settings</a></li>
      <li><a href="log.php"><span class="glyphicon glyphicon-user"></span> Logout</a></li>
      
    </ul>
      </div>
    </nav>
	</br>
	
<div class="container">
	<div class="row">
         <div class="col-8">
		 <div class="panel-group"><h2 class="form-signin-heading">Picture</h2>
		      <div class="panel panel-primary">
      <div class="panel-heading">Upload to your avatar</div>
      <div class="panel-body">
	  <?php
	      $sql = "SELECT * FROM easyuser WHERE id=".$_SESSION['id']."";
                                $result = $conn->query($sql);
                                  if ($result->num_rows > 0) {
                                  while($row = $result->fetch_assoc()) {
                                     echo '<img src="'.$row['avatar'].' " class="rounded mx-auto d-block">';
                                               }
                                  }
									 
								  
	  ?>
             <form method="post" id="upload" enctype="multipart/form-data" >
                  <input type="file" name="file" id="ImageBrowse" multiple="true">
				 <hr>
                       
             </form>	<div id="up"></div> 
			 </div>
    </div>
		 </div>  
		 </div>
         <div class="col-4">
             <div class="panel-group"><h2 class="form-signin-heading">Email and password and username</h2>
		      <div class="panel panel-primary">
      <div class="panel-heading">General</div>
      <div class="panel-body">
<form id="form">
                
			   <label for="exampleFormControlInput1">Username</label>
                  <input type="text"  name="edituser" class="form-control" value="<?php echo $_SESSION['username'];?>" required="true" autofocus="">
				  </br>
               <label for="exampleFormControlInput1">Email address</label>
                  <input type="email"  name="editmail" class="form-control" data-validation="email" value="<?php echo $_SESSION['email'];?>" required="true" autofocus="">
				  </br>
               <label for="exampleFormControlInput1">Password</label>
                  <input type="text"  name="editpass" class="form-control" value="<?php echo $_SESSION['pass'];?>" required="true">
				  </br>
               <div class="checkbox">
               
               </div>
                  <input type="submit" name="submit" value="Submit" class="btn btn-primary mb-2">
             </form>	  <div id="shop"></div></div>
    </div>
		 </div> 
			 
			 
         </div>
     </div>
</div>
</body>

</html>
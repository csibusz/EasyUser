<?php
session_start();
require('function.php');
include('config.php');
// User general settings update
if(isset($_POST['edituser']) || isset($_POST['editmail']) || isset($_POST['editpass'])) {
            
        
			    if(!valid_username($_POST['edituser'])){
				   echo "Username is not correct. Minimum 3 characters and A-z,0-9";
			    }else{
				      if (!valid_email($_POST['editmail'])){
					       echo "Email is not correct";
				      }else{
					         $username=inputfilter($_POST['edituser']);
							 $ip=user_ip();
					         $email=inputfilter($_POST['editmail']);
					         $password=inputfilter(encryptIt($_POST['editpass']));
							 $date = date("Y-m-d h:i:s");
							 $sql = "SELECT * FROM easyuser WHERE id=".$_SESSION['id']."";
                                $result = $conn->query($sql);
                                  if ($result->num_rows > 0) {
                                  while($row = $result->fetch_assoc()) {
                                     $sql ="UPDATE  easyuser SET username='$username', email='$email', password='$password' WHERE id=".$_SESSION['id']."" ;
									 echo'<div id="shop" class="alert alert-success"><center>Changes successfully saved</center></div>';
								 if ($conn->query($sql) === TRUE) {
                                  
                                   } else {
                                            echo "Error: " . $sql . "<br>" . $conn->error;
                                          }
                                               }
                                  } 
					         
  										   
				           }
			        }
			
		    }


?>
<?php
session_start();
require('include/function.php');
include('include/config.php');
if ( !isset($_SESSION['login']) || $_SESSION['login'] !== true) {

if(empty($_SESSION['access_token']) || empty($_SESSION['access_token']['oauth_token']) || empty($_SESSION['access_token']['oauth_token_secret'])){

if ( !isset($_SESSION['token'])) {



 header('Location: index.php');

exit;

}
}
}
if (!isset($_SESSION['superuser'])) {
    header('Location: index.php');
}

// Website settings
if(isset($_POST['title']) || isset($_POST['mail']) || isset($_POST['meta'])) {
            
        
			    
				      
					         $title=inputfilter($_POST['title']);
							 $mail=inputfilter($_POST['mail']);
							 $meta=inputfilter($_POST['meta']);
					         $term=mysqli_real_escape_string($conn,$_POST['term']);
							 $live=inputfilter($_POST['live']);
							 
					         
							 
							 
                                     $sql ="UPDATE  easysettings SET websitename='$title', meta='$meta', reglive='$live', email='$mail', term='$term' WHERE id=1" ;
								 if ($conn->query($sql) === TRUE) {
                                  
                                   } else {
                                            echo "Error: " . $sql . "<br>" . $conn->error;
                                          }
                                               
					         
  										   
				           
			        
			
		    }
?>
<html>
  <head>
     <title><?php echo $sitename;?></title>
	 <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	 <meta name="description" content="<?php echo $sitemeta;?>">
     <link href="css/bootstrap.css" rel="stylesheet">
	 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
     <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
     <script src="//cdnjs.cloudflare.com/ajax/libs/jquery-form-validator/2.3.26/jquery.form-validator.min.js"></script>
	 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	 </head>
<style>
.count{
	font-size: 30px;
    line-height: 47px;
    font-weight: 600;
	color: #73879C;
}
.admin{
	margin-right: 5px;
    margin-bottom: 0;
    margin-left: 5px;
	width:22%;
}
</style>
<body>
<nav class="navbar navbar-expand-md navbar-dark bg-dark">
      <a class="navbar-brand" href="home.php">EasyUser</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample04" aria-controls="navbarsExample04" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarsExample04">
        <ul class="navbar-nav mr-auto">
          <li class="nav-item active">
            <a class="nav-link" href="home.php">Home <span class="sr-only">(current)</span></a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="contact.php">Contact</a>
          </li>
          
        </ul>
        <ul class="nav navbar-nav navbar-right">
		<?php  if(($_SESSION['superuser'])==1){echo'<li><a href="admin.php"><span class="glyphicon glyphicon-home"></span>Admin</a></li>';}  ?>
		<li><a href="settings.php"><span class="glyphicon glyphicon-cog"></span> Settings</a></li>
      <li><a href="log.php"><span class="glyphicon glyphicon-user"></span> Logout</a></li>
      
    </ul>
      </div>
    </nav>
	</br>
<div class="container">
	<div class="row">
	     <div class="col-6 col-md-4"><ul class="navbar-nav navbar-sidenav " id="exampleAccordion">
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="" data-original-title="Dashboard">
          <a class="nav-link" href="admin.php">
            <i class="fa fa-fw fa-dashboard"></i>
            <span class="nav-link-text">Dashboard</span>
          </a>
        </li>
        
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="" data-original-title="Tables">
          <a class="nav-link" href="admin_users.php">
            <i class="fa fa-fw fa-table"></i>
            <span class="nav-link-text">Users</span>
          </a>
        </li>
        
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="" data-original-title="Link">
          <a class="nav-link" href="admin_news.php">
            <i class="fa fa-fw fa-link"></i>
            <span class="nav-link-text">News</span>
          </a>
        </li>
		<li class="nav-item" data-toggle="tooltip" data-placement="right" title="" data-original-title="Link">
          <a class="nav-link" href="admin_settings.php">
            <i class="fa fa-fw fa-link"></i>
            <span class="nav-link-text">Website settings</span>
          </a>
        </li>
      </ul></div>
	     <div class="col-12 col-md-8">
		 <div class="card-deck">
  
    <div class="panel panel-primary admin">
      <div class="panel-heading"><i class="glyphicon glyphicon-user"></i> Total Users</div>
      <div class="panel-body"><div class="count"><?php
	     $sql = "SELECT * FROM easyuser ORDER BY id";
		 if ($result=mysqli_query($conn,$sql))
            {
               $rowcount=mysqli_num_rows($result);
                printf("%d \n",$rowcount);
                 mysqli_free_result($result);
            }
	  ?></div></div>
    </div>
  
  
    <div class="panel panel-success admin">
      <div class="panel-heading"><i class="glyphicon glyphicon-user"></i> Total Males</div>
      <div class="panel-body"><div class="count"><?php
	     $sql = "SELECT * FROM easyuser WHERE gender='male'";
		 if ($result=mysqli_query($conn,$sql))
            {
               $rowcount=mysqli_num_rows($result);
                printf("%d \n",$rowcount);
                 mysqli_free_result($result);
            }
	  ?></div></div>
    </div>
  
  
    <div class="panel panel-danger admin">
      <div class="panel-heading"><i class="glyphicon glyphicon-user"></i> Total Females</div>
      <div class="panel-body"><div class="count"><?php
	     $sql = "SELECT * FROM easyuser WHERE gender='famale'";
		 if ($result=mysqli_query($conn,$sql))
            {
               $rowcount=mysqli_num_rows($result);
                printf("%d \n",$rowcount);
                 mysqli_free_result($result);
            }
	  ?></div></div>
    </div>
  
  
    <div class="panel panel-warning admin">
      <div class="panel-heading"><i class="glyphicon glyphicon-envelope"></i> New message</div>
      <div class="panel-body"><div class="count"><?php
	     $sql = "SELECT * FROM easycontact ORDER BY id";
		 if ($result=mysqli_query($conn,$sql))
            {
               $rowcount=mysqli_num_rows($result);
                printf("%d \n",$rowcount);
                 mysqli_free_result($result);
            }
	  ?></div></div>
    </div>
  
</div>
		 </br></br></br>
		 <div class="panel panel-default">
  <div class="panel-heading">Website settings </div>
  <div class="panel-body">
  
  <?php
	     $sql = "SELECT * FROM easysettings ";
                                $result = $conn->query($sql);
                                  if ($result->num_rows > 0) {
                                  while($row = $result->fetch_assoc()) {
									  echo'
  <form class="form-signin" method="post" action="">
                <div class="row">
    <div class="col">
      <label>Website Title</label>
                  <input type="text"  name="title" class="form-control" value="'.$row['websitename'].'" required="true" autofocus="">
				  </br>
               
    </div>
    <div class="col">
    
               <label>Website Email</label>
                  <input type="text"  name="mail" class="form-control" value="'.$row['email'].'" required="true" autofocus="">
				  </br>
    </div>
    <div class="col">
      
               <label>Website Description</label>
                  <input type="text"  name="meta" class="form-control" value="'.$row['meta'].'" required="true" autofocus="">
				  </br>
    </div>
  </div>
			   <div class="form-group">
                  <label >Term of use:</label>
                  <textarea class="form-control" rows="5" required="true" name="term">'.$row['term'].'</textarea>
               </div>
               <div class="row">
    <div class="col">';
	
	
	
	if($row['reglive']==1){
	
     echo' <div class="form-group">
                  <label for="sel1">Registration live:</label>
                  <select name="live" class="form-control" style="height:auto" required="true">
                    <option value="1" selected>Yes</option>
                    <option value="0">No</option>
                    
                    </select>
               </div>
    </div>';
	}else{
		echo' <div class="form-group">
                  <label for="sel1">Registration live:</label>
                  <select name="live" class="form-control" style="height:auto" required="true">
                    <option value="1" >Yes</option>
                    <option value="0" selected>No</option>
                    
                    </select>
               </div>
    </div>';
	}
	
    echo'<div class="col">
      
    </div>
  </div>
               
			   
               </div>
                  <button class="btn btn-lg btn-primary btn-block" type="submit">Save</button>
             </form></div>
</div>
		 
  ';
								  }
								  }
	  ?>
		 </div>
  
    </div>
</div>
</body>

</html>
<?php



    

?>